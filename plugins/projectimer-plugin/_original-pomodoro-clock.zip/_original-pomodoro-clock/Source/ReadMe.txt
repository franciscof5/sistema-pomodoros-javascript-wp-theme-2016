
	The structure is really straight forward. index.html is the main file that uses animate.js and style.css
	and the image folders Double and Single.