<?php 
	/**
		** Theme: Responsive Slider
		** Author: flytheme
		** Version: 1.0
	**/
	
	$default = array(
			'category' => $category, 
			'orderby' => $orderby,
			'order' => $order, 
			'numberposts' => $numberposts,
	);
	$list = get_posts($default);
	$id = 'sw_reponsive_post_slider_'.rand().time();
	if ( count($list) > 0 ){
?>
	<div id="<?php echo esc_attr( $id ) ?>" class="carousel  yt_post_slide_<?php echo esc_attr( $type ) ?> slide content <?php echo esc_attr( $el_class ) ?>" data-ride="carousel" data-interval="<?php echo esc_attr( $interval ) ?>">
	<?php if( $title != '' ){ ?>
		<div class="block-title <?php echo esc_attr( $style_title ) ?>">
		<?php 
			if($style_title == 'title3'){
				$wordChunks = explode(" ", $title);
				$firstchunk = $wordChunks[0];
				$secondchunk = $wordChunks[1];
				$html.='<h2> <span>'.$firstchunk.'</span> <span class="text-color"> '.esc_html( $secondchunk ).' </span></h2>';
			}else{
				$html.='<h2>
				<span>'.esc_html( $title ).'</span>
			</h2>' ;
			}	
		}		
	?>
			<div class="customNavigation nav-left-product">
				<a title="Previous" class="btn-bs prev-bs fa fa-angle-left"  href="<?php echo esc_attr '.yt_post_slide_'. $type  ?>" role="button" data-slide="prev"></a>
				<a title="Next" class="btn-bs next-bs fa fa-angle-right" href="<?php echo esc_attr '.yt_post_slide_'.$type ?>" role="button" data-slide="next"></a>
			</div>
		</div>
		<div class="carousel-inner">
	<?php foreach( $list as $i => $item ){ ?>
			<div class="item <?php ( $i == 0 ) ? 'active ' : ''; ?>">
				<a href="<?php echo get_permalink( $item->ID ) ?>" title="<?php echo esc_attr( $item->post_title ) ?>"><?php echo get_the_post_thumbnail( $item->ID, 'medium' ) ?></a>
				<div class="carousel-caption-<?php echo esc_attr( $type ) ?> carousel-caption">
					<div class="carousel-caption-inner">
						<a href="<?php echo get_permalink( $item->ID ) ?>"><?php echo esc_html( $item->post_title ) ?></a>
						<div class="item-description"><?php echo wp_trim_words( $item->post_content,$length ) ?></div>
					</div>
				</div>
			</div> 
		<?php } ?>
		</div>
		<div class="carousel-cl-<?php echo esc_attr( $type ) ?> carousel-cl" >
			<a class="left carousel-control" href="<?php echo esc_attr( '.yt_post_slide_'. $type ) ?>" role="button" data-slide="prev"></a>
			<a class="right carousel-control" href="<?php echo esc_attr( '.yt_post_slide_'. $type ) ?>" role="button" data-slide="next"></a>
		</div>
	</div>
<?php } ?>