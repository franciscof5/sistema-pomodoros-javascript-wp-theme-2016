(function( $ ) {
 
    // Add Color Picker to all inputs that have 'color-field' class
    $(function() {
        $('.category-colorpicker').wpColorPicker();
    });
     
})( jQuery );